declare module 'cwebp-bin'
